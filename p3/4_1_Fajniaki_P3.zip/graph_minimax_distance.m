function minimax_distance = graph_minimax_distance(md)
minimax_distance = min(md);
end