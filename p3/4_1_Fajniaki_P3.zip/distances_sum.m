function min_sum = distances_sum(sum_distances)
min_sum = min(sum_distances);
end